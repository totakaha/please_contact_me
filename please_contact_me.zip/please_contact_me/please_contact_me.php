<?php
/*
Plugin Name: please_contact_me
Plugin URI: 
Description: 「お問い合わせはこちら」自動設定
Version: 2.0.0
Author: KCS Contents
Author URI: https://www.kcscorp.jp/network/website/index.html
License: GPL2
*/


//管理画面にメニュー追加
add_action('admin_menu', 'dashboard_menu');

function dashboard_menu() {
  add_options_page('問い合わせ先一覧', '問い合わせ先一覧', 8, 'dashboard_menu', 'dashboard_options_page');
}

function dashboard_options_page() {
?>
  <div class="wrap">
    <h2>問い合わせ先一覧</h2>
<?php
	/* CSVファイルopen、読み取り */
	$fileName = dirname(__FILE__) ."/writer.csv";
	$file = new SplFileObject($fileName);
	$file->setFlags(SplFileObject::READ_CSV);
	foreach ($file as $line) {
		if(is_null($line[0])){
			$records[] = $line;
		}
	}
	/* 管理画面へ編集 */
	$theFile = fopen( $fileName, "r");
	$cnt=0;
	echo "<table border='1'><tr><th>タグ</th><th>部署等</th><th>URL</th><th>施設</th><th>住所</th><th>電話番号</th><th>ファックス</th></tr>";
	while(!feof($theFile)){
		$csv = fgets($theFile);
		$row[$cnt]=explode(",",$csv);

		echo "<tr>";
		foreach($row[$cnt] as $value){
			$value = htmlspecialchars($value);
			$data = mb_convert_encoding($value, 'UTF-8', 'sjis-win');
			echo "<td>" . $data . "</td>";
		}
		echo "</tr>";
		$cnt++;
	}
	echo "</table>";
	fclose( $theFile );

	echo"</div>";
}


/* すでに定義されていない場合に実行 */
if( !function_exists("please_contact_me")){
	function please_contact_me($content){
		
		/* 投稿で設定された部署を取得 */
		$post_tags = get_the_tags();
		$tag = $post_tags[0]->name;

		/* スクリプトと同じディレクトリ内のcsvファイルを指定 */
		$fileName = dirname(__FILE__) ."/writer.csv";

		/* 固定ページ以外の場合＆ファイルが存在する場合に実行 */
		if( !is_page( ) && file_exists( $fileName )){

			/* CSVファイルを開き、その内容を読み取る */
			$theFile = fopen( $fileName, "r");
			$cnt=0;
			$msg = "";
			while(!feof($theFile)){
				$csv = fgets($theFile);
				$row[$cnt]=explode(",",$csv);

				if($tag === $row[$cnt][0]){
					foreach($row[$cnt] as $value){
						$value = htmlspecialchars($value);
						$data[] = mb_convert_encoding($value, 'UTF-8', 'sjis-win');
					}
					$msg = Add_to_the_bottom($data);
				}
				$cnt++;
			}
			fclose( $theFile );
			if(!$msg){
				/* データがない場合、基本情報設定 */
				$msg = basic_information();
			}

			/* 末尾にテキストファイルの内容を追加 */
			return $content . stripslashes( $msg );
		} else{

			/* 固定ページの場合＆ファイルが存在しない場合実行されない */
			return $content;
		}
	}

	/*	フィルタ機能をフックに追加 */
	add_filter('the_content', 'please_contact_me');
}

function Add_to_the_bottom($data){
$msg = <<<EOS
	<h2>問い合わせ先</h2>
	<h3>このページに関するお問い合わせは<a href="$data[2]"> $data[1]</a>です。</h3>
	<p>$data[3]　$data[4]</p>
	<p>電話番号：$data[5]　ファックス番号：$data[6]</p>
EOS;
	return $msg;
};

function basic_information($data){
$msg = <<<EOS
	<p>　</p>
EOS;
	return $msg;
};



?>